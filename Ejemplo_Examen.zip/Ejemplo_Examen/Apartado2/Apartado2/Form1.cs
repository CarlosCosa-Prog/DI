using iText.Kernel.Pdf;
using iText.Layout.Element;
using iText.Layout.Properties;
using MySql.Data.MySqlClient;
using System.Data;

namespace Apartado2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void boton1_Click(object sender, EventArgs e)
        {

        }

        private void boton2_Click(object sender, EventArgs e)
        {
            // Si la carpeta no existe, la crea
            string carpeta = @"C:\pdf";
            if (!Directory.Exists(carpeta))
            {
                Directory.CreateDirectory(carpeta);
            }

            // Ruta donde se guardará el PDF
            string rutaPDF = Path.Combine(carpeta, "tabla.pdf");

            // Crear un documento PDF
            using (var pdfWriter = new PdfWriter(rutaPDF))
            {
                using (var pdf = new PdfDocument(pdfWriter))
                {
                    // Crear un documento iText
                    var document = new Document(pdf);

                    // Agregar cabecera al documento
                    Paragraph cabecera = new Paragraph("PDF COCHES");
                    cabecera.SetTextAlignment(TextAlignment.CENTER);
                    cabecera.SetFontSize(20);
                    document.Add(cabecera);

                    // Agregar tabla
                    Table tabla = new Table(3);

                    // Encabezados de la tabla con fondo gris
                    tabla.AddHeaderCell(new Cell().Add(new Paragraph("Marca")));
                    tabla.AddHeaderCell(new Cell().Add(new Paragraph("Modelo")));
                    tabla.AddHeaderCell(new Cell().Add(new Paragraph("Telefono")));


                    // Recorrer filas del DataGridView
                    foreach (DataGridViewRow fila in dataGridView.Rows)
                    {
                        if (!fila.IsNewRow) // ignorar fila vacía de edición
                        {
                            tabla.AddCell(fila.Cells["nombre"].Value?.ToString() ?? "");
                            tabla.AddCell(fila.Cells["apellidos"].Value?.ToString() ?? "");
                            tabla.AddCell(fila.Cells["telefono"].Value?.ToString() ?? "");
                        }
                    }

                    tabla.SetTextAlignment(TextAlignment.CENTER);
                    tabla.SetHorizontalAlignment(iText.Layout.Properties.HorizontalAlignment.CENTER);
                    tabla.SetWidth(500);
                    document.Add(tabla);

                    // Cierra el documento
                    document.Close();

                    // Mensaje que se muestra al crear el pdf
                    MessageBox.Show(
                    $"PDF generado correctamente en:\n{rutaPDF}",
                    "Exito",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                    );
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string consulta = "SELECT * FROM coches";

            MySqlDataAdapter adapter = new MySqlDataAdapter(consulta, conexion.Conectar());

            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView.DataSource = dt;
        }
    }
    internal class conexion
    {
        private static string servidor = "localhost";
        private static string bd = "taller_carlos_cosa";
        private static string usuario = "root";
        private static string pass = "";

        public static MySqlConnection Conectar()
        {
            CrearBaseDeDatosSiNoExiste();
            CrearTablaSiNoExiste();

            string cadenaConexion = $"Server={servidor};Database={bd};User ID={usuario};Password={pass};";
            return new MySqlConnection(cadenaConexion);
        }
        public static void CrearBaseDeDatosSiNoExiste()
        {
            string cadenaConexion = $"Server={servidor};User ID={usuario};Password={pass};";
            using (MySqlConnection conexion = new MySqlConnection(cadenaConexion))
            {
                conexion.Open();
                string crearBD = $"CREATE DATABASE IF NOT EXISTS {bd} CHARACTER SET utf8mb4;";
                new MySqlCommand(crearBD, conexion).ExecuteNonQuery();
            }
        }

        public static void CrearTablaSiNoExiste()
        {
            string cadenaConexion = $"Server={servidor};Database={bd};User ID={usuario};Password={pass};";
            using (MySqlConnection conexion = new MySqlConnection(cadenaConexion))
            {
                conexion.Open();

                string crearTablaCoches = @"CREATE TABLE IF NOT EXISTS coches (
                    idCoche INT(11) NOT NULL AUTO_INCREMENT,
                    marca VARCHAR(50) NOT NULL,
                    modelo VARCHAR(50) NOT NULL,
                    anio INT(4) NOT NULL,
                    numeroChasis VARCHAR(20) NOT NULL,
                    PRIMARY KEY (idCoche))";


                new MySqlCommand(crearTablaCoches, conexion).ExecuteNonQuery();
            }
        }
    }
}
