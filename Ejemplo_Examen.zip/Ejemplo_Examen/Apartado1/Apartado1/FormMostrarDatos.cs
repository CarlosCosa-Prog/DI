﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Apartado1
{
    public partial class FormMostrarDatos : Form
    {
        public FormMostrarDatos()
        {
            InitializeComponent();
        }

        private void FormMostrarDatos_Load(object sender, EventArgs e)
        {
            // añade al combo box el nombre de las tablas
            comboBox1.Items.Add("clientes");
            comboBox1.Items.Add("coches");

            // selecciona la primera opcion por defecto
            comboBox1.SelectedIndex = 0;
        }

        private void botonMostrar_Click(object sender, EventArgs e)
        {
            mostrarTabla();

        }
        public void mostrarTabla()
        {
            string seleccionado = comboBox1.SelectedItem.ToString();

            
            string consulta = "SELECT * FROM " + seleccionado;

            MySqlDataAdapter adapter = new MySqlDataAdapter(consulta, conexion.Conectar());

            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void botonEliminar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // guarda en una variable la fila seleccionada
                DataGridViewRow fila = dataGridView1.SelectedRows[0];

                // guarda en una variable el primer campo de la fila (id)
                var id = fila.Cells[0].Value;

                // guarda el nombre de la tabla seleccionada segun el valor del comboBox
                string tabla = comboBox1.SelectedItem.ToString();

                // guarda el nombre del id para pasarselo al sql
                string columnaId = dataGridView1.Columns[0].Name;

                string consulta = "DELETE FROM " + tabla + " WHERE " + columnaId + " = @id";

                try
                {
                    using (MySqlConnection conn = conexion.Conectar())
                    {
                        conn.Open();
                        MySqlCommand cmd = new MySqlCommand(consulta, conn);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.ExecuteNonQuery();
                    }

                    // refresca el DataGridView para ver los cambios
                    mostrarTabla();

                    MessageBox.Show("Fila eliminada correctamente.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Selecciona una fila para eliminar.");
            }
        }
    }
}
